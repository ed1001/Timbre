class Clock
end
